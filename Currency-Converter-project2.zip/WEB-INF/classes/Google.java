import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.IOException;
import java.net.URL;
import java.net.HttpURLConnection;

public class Google extends HttpServlet {

    public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
                    throws IOException,ServletException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String c = request.getParameter("amount");
		String d = request.getParameter("from");
        String e = request.getParameter("to");

		Googlem la = new Googlem();
		String result = la.getF(c,d,e);
		out.println(result);
		
		/*
		request.setAttribute("from",d);
		request.setAttribute("to",e);
		request.setAttribute("amount",c);
		
		RequestDispatcher view = request.getRequestDispatcher("result.jsp");
		view.forward(request,response);*/
    }
}