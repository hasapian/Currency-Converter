public class MyLink{
	private String link;
	
	public MyLink(String link){
		this.link = link;
	}
	
	public String getLink(){
		return link;
	}
}