﻿function ajax()
{
	//alert("Amount must be positive");
	xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange=function()
	  {
		document.getElementById("pad").innerHTML=xmlhttp.responseText;
	  }
	xmlhttp.open("GET","http://localhost:8080/project2/convert?amount="+document.input.amount.value+"&from="+document.input.from.value+"&to="+document.input.to.value,true);
	xmlhttp.send();
	
}

function validateForm()
{
var x=document.forms["input"]["amount"].value;
if (x==null || x=="")
  {
  alert("Amount must be filled out");
  return false;
  }
else if(x<0)
	{
	alert("Amount must be positive");
  return false;
  }
 else if (isNaN(x) == true)
   {
      alert("Amount must be a number.");
      return false;
   }
   else return true;
}

function test()
{
	alert("Save as .zip");	
}