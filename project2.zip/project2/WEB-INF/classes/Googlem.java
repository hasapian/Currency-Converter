import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.IOException;
import java.net.URL;
import java.net.HttpURLConnection;

public class Googlem {

	public String getF(String myamount, String baseCurrency, String termCurrency) throws IOException {

		
		String google = "http://www.google.com/ig/calculator?hl=en&q=";
		
        String charset = "UTF-8";
		
		String mine = google + myamount+ baseCurrency + "=?" + termCurrency;
		
		URL url = new URL(mine);
		
		HttpURLConnection urlc = (HttpURLConnection)url.openConnection();
		
		urlc.setAllowUserInteraction(false);
		
		urlc.setDoInput( true );
		urlc.setDoOutput( false );
		urlc.setUseCaches( true );
		urlc.setRequestMethod("GET");
		urlc.connect();
		
		BufferedReader in = new BufferedReader(new InputStreamReader(urlc.getInputStream()));
		
		String line = null;
		
		line = in.readLine();

		int pos = line.indexOf("rhs",7);

		int keno = line.indexOf("\"",pos+6);

		String rate = line.substring(pos+6,keno-1);
		
		//double aDouble = Double.parseDouble(rate);
			
		return rate;
	}
}