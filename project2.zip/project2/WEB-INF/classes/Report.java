import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class Report extends HttpServlet{

	public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
                    throws IOException,ServletException {
		
		//String link = getServletContext().getInitParameter("reportLink");
		
		MyLink link = (MyLink)getServletContext().getAttribute("link");
		response.sendRedirect(link.getLink());
	}
}